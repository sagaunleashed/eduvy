/*
Template Name: Fadmin - Responsive Bootstrap Admin Dashboard
Author: ThemesBoss
File: Main Js File
*/


$('#footable_exa').footable({
    "sorting": {
        "enabled": true
    }
});