from django.db import models
from phonenumber_field.modelfields import PhoneNumberField
from django.utils.translation import gettext_lazy as _
from datetime import date
from multiselectfield import MultiSelectField
from django.utils import timezone


def branch_upload(instance, filename):
    # file will be uploaded to MEDIA_ROOT/user_<id>/<filename>
    return 'Branches/{0}/{1}'.format(instance.BranchName,filename)


# Create your models here.
class Institution(models.Model):
    def user_directory_path(instance, filename):
        # file will be uploaded to MEDIA_ROOT/user_<id>/<filename>
        return '{0}/{1}'.format(instance.name, filename)
    def user_directory_path(instance, filename):
        # file will be uploaded to MEDIA_ROOT/user_<id>/<filename>
        return '{0}/{1}'.format(instance.name, filename)
    user = models.IntegerField(verbose_name="Users",default=1)
    institutionCode = models.CharField(verbose_name="Institution Code",default="000",max_length=150,unique=True)
    name = models.CharField(verbose_name="Institution Name",default="Name",max_length=150)
    chairmanName = models.CharField(verbose_name="Chairman Name",default="Chairman Name", max_length=150)
    contactPersonName = models.CharField(verbose_name="Contact Person Name",default="Contact Person Name", max_length=150)
    contactPersonPhone = PhoneNumberField(blank=True)
    contactPersonEmail = models.EmailField(verbose_name="Contact Person Email", default="Contact Person Email",max_length=150)
    address =  models.CharField(verbose_name="Address",default="Address",max_length=500)
    image = models.ImageField(verbose_name="Image",upload_to=user_directory_path, default='static/images/brochure.jpg')
    status = [('Active','Active'),('Inactive','Inactive')]
    Status = models.CharField(verbose_name="Status",choices=status,default="Active",max_length=50)
    cityId = models.IntegerField(verbose_name="City ID",default=1)
    stateID = models.IntegerField(verbose_name="State Id",default=1)
    logo = models.ImageField(upload_to=user_directory_path, default='brochure.jpg')
    description = models.TextField(_(
        'description'), max_length=500, blank=True)
    brochure = models.ImageField(upload_to =user_directory_path, default='brochure.jpg')
    

    def __str__(self):
        return self.name

    class Meta:
        db_table = 'Institution'
        managed = True
        verbose_name = 'Institution'
        verbose_name_plural = 'Institutions'


# Create your models here.
class Branch(models.Model):
    user = models.IntegerField(verbose_name="User",default=1)
    BranchCode = models.CharField(max_length=10,verbose_name="Branch Code",unique=True,blank=True)
    BranchName = models.CharField(max_length=100,verbose_name="Branch Name",unique=True,blank=True)
    Image = models.ImageField(upload_to = branch_upload,verbose_name="BranchImage")
    status = [('Active' , 'Active'),('Inactive','Inactive')]
    Status = models.CharField(max_length=20,choices=status)
    DateofJoin = models.DateField(verbose_name="Date of Joining",default=date.today) 
    def __str__(self):
        return self.BranchName
    
    class  Meta:
        db_table = 'Branch'
        managed = True
        verbose_name = 'Branch' 
        verbose_name_plural = 'Branches'
        ordering = ['-DateofJoin']

class SupportingDoc(models.Model):
    user = models.IntegerField(verbose_name="User",default=1)
    DocumentName = models.CharField(max_length=25,default=None,verbose_name="Supporting Documents",unique=True)
    status = [('Active', 'Active'),('Inactive','Inactive')]
    Status = models.CharField(max_length=25,choices=status)
    DateofAdd = models.DateField(verbose_name="Date of Joining",default=date.today)
    def __str__(self):
        return self.DocumentName
    
    class Meta:
        db_table = 'Supporting Documents'
        managed = True
        verbose_name = 'Supporting Document'
        verbose_name_plural = 'Supporting Documents'

class Course(models.Model):    
    user = models.IntegerField(verbose_name="User",default=1)
    CourseCode = models.CharField(max_length=10,verbose_name="Course Code",unique=True)
    CourseName = models.CharField(max_length=100,verbose_name="Course Name",unique=True)
    Branch = models.ForeignKey(Branch,on_delete=models.SET_DEFAULT,default="1")
    CourseDuration = models.IntegerField(verbose_name="Course Duration")
    CourseDescription = models.TextField(verbose_name="Course Description")
    CourseImage = models.ImageField()
    status = [('Active' , 'Active'),('Inactive','Inactive')]
    Status = models.CharField(max_length=20,choices=status)
    DateofJoin = models.DateField(verbose_name="Date of Joining",default=date.today)
    SupDoc = models.CharField(verbose_name="Supporting Doc",max_length=25,default=None)
    # SupDoc = MultiSelectField(choices="",max_length=100)
    CourseImage = models.ImageField(verbose_name="Course Image")


    def __str__(self):
        return self.CourseName
    

    class Meta:
        db_table = 'Courses'
        managed = True
        verbose_name = 'Course'
        verbose_name_plural = 'Courses'


class planBanner(models.Model):
    user = models.IntegerField(verbose_name="User ID",default=1)
    Title = models.CharField(verbose_name="Title",default="Title",max_length=150 )
    Description = models.CharField(verbose_name="Description",default="Description",max_length=500 )
    status = [('Active','Active'),('Inactive','Inactive')]
    Status = models.CharField(verbose_name="Status",default="Active",choices=status,max_length=150)
    Image = models.ImageField(upload_to= "Planbanner/")
    date = models.DateField(default=date.today)
    def __str__(self):
        return self.Title

    class Meta:
        db_table = 'Plan Banner'
        managed = True
        verbose_name = 'Planbanner'
        verbose_name_plural = 'Planbanners'


class introBanner(models.Model):
    user = models.IntegerField(verbose_name="User ID",default=1)
    Title = models.CharField(verbose_name="Title",default="Title",max_length=150 )
    Description = models.CharField(verbose_name="Description",default="Description",max_length=500 )
    status = [('Active','Active'),('Inactive','Inactive')]
    Status = models.CharField(verbose_name="Status",default="Active",choices=status,max_length=150)
    Image = models.ImageField(upload_to= "Introbanner/")
    date = models.DateField(default=date.today)
    def __str__(self):
        return self.Title

    class Meta:
        db_table = 'Intro Banner'
        managed = True
        verbose_name = 'Introbanner'
        verbose_name_plural = 'Introbanners'

class instituteBanner(models.Model):
    user = models.IntegerField(verbose_name="User ID",default=1)
    Title = models.CharField(verbose_name="Title",default="Title",max_length=150 )
    status = [('Active','Active'),('Inactive','Inactive')]
    Status = models.CharField(verbose_name="Status",default="Active",choices=status,max_length=150)
    Image = models.ImageField(upload_to= "institutebanner/")
    date = models.DateField(default=date.today)
    def __str__(self):
        return self.Title

    class Meta:
        db_table = 'institute Banner'
        managed = True
        verbose_name = 'institutebanner'
        verbose_name_plural = 'institutebanners'

    

