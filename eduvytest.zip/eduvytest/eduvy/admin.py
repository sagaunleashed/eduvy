from django.contrib import admin

# Register your models here.
from .models import Institution
admin.site.register(Institution)
from .models import Branch
admin.site.register(Branch)
from .models import Course
admin.site.register(Course)
from .models import SupportingDoc
admin.site.register(SupportingDoc)
from .models import introBanner
admin.site.register(introBanner)
from .models import planBanner
admin.site.register(planBanner)
from .models import instituteBanner
admin.site.register(instituteBanner)