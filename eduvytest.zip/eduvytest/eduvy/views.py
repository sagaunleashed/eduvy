from django.shortcuts import render,redirect
from django.views.decorators.csrf import csrf_exempt
from django.contrib.auth.models import  auth
from django.contrib.auth.decorators import login_required, user_passes_test
from users.models import NewUser
from eduvy.models import Institution,Branch,SupportingDoc,Course,introBanner,instituteBanner,planBanner
from django.contrib import messages
from django.core.mail import send_mail
import pymongo,json
from django.http import JsonResponse,HttpResponse
from django.conf import settings

# Create your views here.
@login_required(login_url="login")
def index(request):
    request.session['title'] = ""
    # pagetitle ={ title : "Eduvy, India's first online admission facilitating app"}
    if request.user.email:
        return redirect("dashboard")
    else:
        return login(request)


@csrf_exempt
def login(request):
    if request.method == "POST":
        username = request.POST["username"]
        password = request.POST["password"]
        user = auth.authenticate(username=username, password=password)
        if user is not None:
            auth.login(request, user)
            return redirect("dashboard")
        else:
            messages.info(request, "Invalid Credentials")
            return redirect("login")
    else:

        return render(request, "index.html")
    return render(request, "index.html")


def logout(request):
    auth.logout(request)
    return redirect("/")


@login_required(login_url="login")
def dashboard(request):
    # users  = Institution.objects.get(user = request.user.id)
    # request.session['college_name']  = users.name
    # request.session['college_id']  = users.id
    # print(request.session['college_name'])
    # print(request.session['college_id'])
    request.session['title'] = "Dashboard"
    return render(request, "dashboard.html")
    

def send_email(subject, body, email):
    try:
        email_msg = EmailMessage(subject, body, settings.EMAIL_HOST_USER, [settings.EMAIL_HOST_USER], reply_to=[email])
        email_msg.send()
        return "Message sent :)"
    except:
        return redirect('dashboard')


@login_required(login_url="login")
def institution(request):
    request.session['title'] = "Institution"
    try:
        if request.method == "POST":
            name = request.POST['institution_name']
            institution_code = request.POST['institution_code']
            state = request.POST['state']
            city = request.POST['city']
            address = request.POST['address']
            chairman_name = request.POST['chairman_name']
            contact_person_name = request.POST['contact_person_name']
            contact_person_email = request.POST['contact_person_email']
            contact_person_phone = request.POST['contact_person_phone']
            institution_image = request.FILES['institution_image']
            status = request.POST['status']
            randompass = NewUser.objects.make_random_password()
            print(randompass)
            userreg = NewUser(email = contact_person_email,is_institute = True,is_active =True) 
            userreg.set_password(randompass)     
            userreg.save()
            InstituteSave = Institution(institutionCode = institution_code, name = name, chairmanName = chairman_name, contactPersonEmail = contact_person_email, contactPersonName = contact_person_name, contactPersonPhone = contact_person_phone, address = address, image = institution_image , Status = status, cityId = city, stateID = state,)
            InstituteSave.save()
            subject = 'welcome to Eduvy'
            message = f'Hi, thank you for registering in Eduvy.Your Password is {randompass}'
            email_from = settings.EMAIL_HOST_USER
            recipient_list = [contact_person_email, ]
            send_mail( subject, message, email_from, recipient_list )
            return redirect('institution')
    except Exception :
        return render(request,'institutions.html')
    if request.user.is_superuser:
        institute = Institution.objects.filter(user=request.user.id)
        return render(request,'institutions.html',{'institute':institute})

@csrf_exempt
def statecity(request):
    if request.method == "POST":
        state_id = request.POST['state_id']
        client = pymongo.MongoClient("mongodb://localhost:27017/")
        # Database Name
        db = client["eduvytest"]
        
        # Collection Name
        con = db["Cities"]
        myquery = { "stateId": state_id }
        x = con.find(myquery)
        city= []
        for data in x:
            cityid  = data['id']
            cityName = data['city']
            c = {"id" : cityid,"city" : cityName}
            city.append(c)
        data = json.dumps(city)
        return HttpResponse(data)
    return redirect('institution')

@login_required(login_url="login")
@csrf_exempt
def branch(request):
    request.session['title'] = "Branch"
    if request.method == "POST":
        BranchCode = request.POST["branch_code"]
        Branchname = request.POST["branch_name"]
        Image = request.FILES["branch_image"]
        Status = request.POST["status"]
        BranchSave = Branch(
            BranchCode=BranchCode, BranchName=Branchname, Image=Image, Status=Status
        )
        BranchSave.save()
        return redirect('branch')
    if request.user.is_superuser:
        branch = Branch.objects.all()
        return render(request, "branch.html", {"branches": branch})
    if request.user.is_institute:
        branch = Branch.objects.filter(user=request.user.id)
        return render(request, "branch.html", {"branches": branch})


@login_required(login_url="login")
@csrf_exempt
def course(request):
    request.session['title'] = "Course"
    if request.method == "POST":
        BranchID = request.POST['branch_id']
        Branches = Branch.objects.get(id = BranchID)
        CourseCode = request.POST["course_code"]
        Coursename = request.POST["course_name"]
        Duration = request.POST['duration']
        Descrip = request.POST['description']
        Doc = request.POST['documents']
        Image = request.FILES["course_image"]
        Status = request.POST["status"]

        CourseSave = Course(
            Branch=Branches, CourseCode=CourseCode, CourseName=Coursename, CourseDuration=Duration, CourseDescription = Descrip, SupDoc = Doc, CourseImage = Image, Status = Status
        )
        CourseSave.save()
        return redirect("course")
    if request.user.is_superuser:
        course = Course.objects.all()
        branch = Branch.objects.all()
        sup = SupportingDoc.objects.all()
        context = {"course" : course,"branch" : branch,"sup" : sup}
        return render(request, "course.html", context)
    if request.user.is_institute:
        course = Course.objects.filter(user=request.user.id)
        branch = Branch.objects.all()
        sup = SupportingDoc.objects.all()
        context = {"course" : course,"branch" : branch,"sup" : sup}
        return render(request, "course.html", context)

@csrf_exempt
def delete_branch(request):
    if request.method == "POST":
        id = request.POST["id"]
        instance = Branch.objects.filter(id=id)
        instance.delete()
        # return redirect(branch)
        data = {
        'is_taken': "deleted"
        }
        return JsonResponse(data)
    return redirect(branch)

@csrf_exempt
def delete_institutebanner(request):
    if request.method == "POST":
        id = request.POST["id"]
        instance = instituteBanner.objects.filter(id=id)
        instance.delete()
        # return redirect(branch)
        data = {
        'is_taken': "deleted"
        }
        return JsonResponse(data)
    return redirect(institutebanner)


@csrf_exempt
def delete_introbanner(request):
    if request.method == "POST":
        id = request.POST["id"]
        instance = introBanner.objects.filter(id=id)
        instance.delete()
        # return redirect(branch)
        data = {
        'is_taken': "deleted"
        }
        return JsonResponse(data)
    return redirect(introbanner)


@csrf_exempt
def delete_institute(request):
    if request.method == "POST":
        id = request.POST["id"]
        instance = Institution.objects.get(id=id)
        instance.delete()
        # userDelete = NewUser.objects.get(email = instance.contactPersonEmail) 
        print(instance)
        # return redirect(branch)
        data = {
        'is_taken': "deleted"
        }
        return JsonResponse(data)
    return redirect(institution)

@csrf_exempt
def delete_course(request):
    if request.method == "POST":
        id = request.POST["id"]
        print(id)
        instance = Course.objects.filter(id=id)
        instance.delete()
        return redirect(branch)
        # data = true
        # return JsonResponse(data)
    return redirect(branch)


@csrf_exempt
def list_branch(request):
    if request.method == "POST":
        id = request.POST['id']
        instance = Branch.objects.filter(id=id).values()
        Code = instance[0]['BranchCode']
        Name = instance[0]['BranchName']
        Image = instance[0]['Image']
        Status = instance[0]['Status']
        ID = instance[0]['id']
        print(Image)
        context = [ID,Code,Name,Image,Status]
        data = json.dumps(context)
        return HttpResponse(data)

@csrf_exempt
def list_institute(request):
    if request.method == "POST":
        id = request.POST['id']
        instance = Institution.objects.filter(id=id).values()
        print(instance)
        Name = instance[0]['name']
        State = instance[0]['stateID']
        City = instance[0]['cityId']
        Address = instance[0]['address']
        Chairman = instance[0]['chairmanName']
        Chairperson = instance[0]['contactPersonName']
        email = instance[0]['contactPersonEmail']
        phone = instance[0]['contactPersonPhone']
        image = instance[0]['image']
        Status = instance[0]['Status']
        ID = instance[0]['id']
        institutionCode = instance[0]['institutionCode']
        context = [ID,Name,State,City,Address,Chairman,Chairperson,email,phone,image,Status,institutionCode]
        data = json.dumps(context)
        return HttpResponse(data)


@csrf_exempt
def list_course(request):
    if request.method == "POST":
        id = request.POST['id']
        instance = Course.objects.filter(id=id).values()
        Code = instance[0]['CourseCode']
        Name = instance[0]['CourseName']
        branch_id = instance[0]['Branch_id']
        b = Branch.objects.filter(id = branch_id).values()
        branch = b[0]['BranchName']
        duration = instance[0]['CourseDuration']
        desc = instance[0]['CourseDescription']
        Image = instance[0]['CourseImage']
        Status = instance[0]['Status']
        ID = instance[0]['id']
        context = [ID,Code,Name,branch,duration,desc,Image,Status]
        print(context)
        data = json.dumps(context)
        return HttpResponse(data)
    return HttpResponse("hello")


@csrf_exempt
def list_doc(request):
    if request.method == "POST":
        id = request.POST['id']
        instance = SupportingDoc.objects.filter(id=id).values()
        Name = instance[0]['DocumentName']
        Status = instance[0]['Status']
        ID = instance[0]['id']
        context = [Name,Status,ID]
        print(context)
        data = json.dumps(context)
        return HttpResponse(data)
    return HttpResponse("hello")

@csrf_exempt
def list_planbanner(request):
    if request.method == "POST":
        id = request.POST['id']
        instance = planBanner.objects.filter(id=id).values()
        Image = instance[0]['Image']
        Title = instance[0]['Title']
        Description = instance[0]['Description']
        Status = instance[0]['Status']
        ID = instance[0]['id']
        context = [ID,Image,Title,Description,Status]
        print(context)
        data = json.dumps(context)
        return HttpResponse(data)
    return HttpResponse("hello")

@csrf_exempt
def list_introbanner(request):
    if request.method == "POST":
        id = request.POST['id']
        instance = introBanner.objects.filter(id=id).values()
        Image = instance[0]['Image']
        Title = instance[0]['Title']
        Description = instance[0]['Description']
        Status = instance[0]['Status']
        ID = instance[0]['id']
        context = [ID,Image,Title,Description,Status]
        print(context)
        data = json.dumps(context)
        return HttpResponse(data)
    return HttpResponse("hello")

@csrf_exempt
def list_institutebanner(request):
    if request.method == "POST":
        id = request.POST['id']
        instance = instituteBanner.objects.filter(id=id).values()
        Image = instance[0]['Image']
        Title = instance[0]['Title']
        Status = instance[0]['Status']
        ID = instance[0]['id']
        context = [ID,Image,Title,Status]
        print(context)
        data = json.dumps(context)
        return HttpResponse(data)
    return HttpResponse("hello")


@csrf_exempt 
def update_branch(request):

    if request.method == "POST":
        ID = request.POST['_id']
        code = request.POST['branch_code']
        Name = request.POST['branch_name']
        Image = request.FILES['branch_image_up']
        status = request.POST['status']
        branch = Branch.objects.get(id = ID)
        branch.BranchName = Name
        branch.BranchCode = code
        branch.Image = Image
        branch.Status = status
        branch.save()

    return redirect('branch')

@csrf_exempt 
def update_institute(request):

    if request.method == "POST":
        ID = request.POST['_id']
        name = request.POST['institution_name']
        code = request.POST['institution_code']
        state = request.POST['state']
        city = request.POST['city']
        address = request.POST['address']
        chairman_name = request.POST['chairman_name']
        contact_person_name = request.POST['contact_person_name']
        contact_person_email = request.POST['contact_person_email']
        contact_person_phone = request.POST['contact_person_phone']
        institution_image = request.FILES['institution_image']
        status = request.POST['status']
        branch = Institution.objects.get(id = ID)
        branch.institutionCode  = code
        branch.contactPersonEmail  = contact_person_email
        branch.name = name
        branch.stateID = state
        branch.cityId = city
        branch.address = address
        branch.chairmanName = chairman_name
        branch.contactPersonName = contact_person_name
        branch.contactPersonPhone = contact_person_phone
        branch.image = institution_image
        branch.Status = status
        branch.save()
        # new = NewUser.objects.filter(email = contact_person_email)
    return redirect('institution')


@csrf_exempt     
def update_course(request):

    if request.method == "POST":
        ID = request.POST['_id']
        code = request.POST['branch_code']
        Name = request.POST['branch_name']
        Image = request.FILES['branch_image_up']
        status = request.POST['status']
        branch = Branch.objects.get(id = ID)
        branch.BranchName = Name
        branch.BranchCode = code
        branch.Image = Image
        branch.Status = status
        branch.save()

    return redirect('branch')

@csrf_exempt 
def update_doc(request):

    if request.method == "POST":
        ID = request.POST['_id']
        
        Name = request.POST['name']
        status = request.POST['status']
        doc = SupportingDoc.objects.get(id = ID)
        doc.DocumentName = Name
        doc.Status = status
        doc.save()

    return redirect('supporting_documents')



@csrf_exempt 
def supporting_documents(request):
    
    request.session['title'] = "Supporting Documents"
    if request.method == "POST":
        DocName = request.POST['name']
        Status = request.POST['status']
        sup_doc = SupportingDoc(DocumentName = DocName, Status = Status)
        sup_doc.save()
        return redirect(supporting_documents)
    sup_doc = SupportingDoc.objects.all()
    return render(request,"supporting-document.html",{'sup_doc': sup_doc})

@csrf_exempt
def delete_supporting_doc(request):
    if request.method == "POST":
        id = request.POST["id"]
        instance = SupportingDoc.objects.filter(id=id)
        instance.delete()
        # return redirect(branch)
        data = {
        'is_taken': "deleted"
        }
        return JsonResponse(data)
    return redirect(supporting_documents)


@csrf_exempt
def introbanner(request):    
    request.session['title'] = "Intro Banner"
    if request.method == "POST":
        userid = request.user.id
        Image = request.FILES['intro_banner_image']
        Title = request.POST['title']
        Desc = request.POST['description']
        status = request.POST['status']
        introsave = introBanner(user = userid, Title = Title, Description = Desc, Status = status, Image = Image)
        introsave.save()
        return redirect(introbanner)
    
    intro  = introBanner.objects.all()
    return render(request,"intro-banner.html",{'intro': intro})

@csrf_exempt
def planbanner(request):
    request.session['title'] = "Plan Banner"
    if request.method == "POST":
        userid = request.user.id
        Image = request.FILES['intro_banner_image']
        Title = request.POST['title']
        Desc = request.POST['description']
        status = request.POST['status']
        plansave = planBanner(user = userid, Title = Title, Description = Desc, Status = status, Image = Image)
        plansave.save()
        return redirect(planbanner)
    
    plan  = planBanner.objects.all()
    return render(request,"plan-banner.html",{'plan': plan})

@csrf_exempt
def institutebanner(request):
    request.session['title'] = "Institute Banner"
    if request.method == "POST":
        userid = request.user.id
        Image = request.FILES['banner_image']
        Title = request.POST['title']
        status = request.POST['status']
        institutesave = instituteBanner(user = userid, Title = Title,Status = status, Image = Image)
        institutesave.save()
        return redirect(institutebanner)
    if request.user.is_superuser:
        institute  = instituteBanner.objects.all()
        return render(request,"institute-banner.html",{'institute': institute})
    if request.user.is_institute:
        institute  = instituteBanner.objects.filter(user=request.user.id)
        return render(request,"institute-banner.html",{'institute': institute})


@csrf_exempt
def delete_planbanner(request):
    if request.method == "POST":
        id = request.POST["id"]
        instance = planBanner.objects.filter(id=id)
        instance.delete()
        # return redirect(branch)
        data = {
        'is_taken': "deleted"
        }
        return JsonResponse(data)
    return redirect(planbanner)

@csrf_exempt
def profile(request):
    if request.method == "POST":
        ID = request.POST['_id']
        brochure = request.FILES['brochure']
        name = request.POST['name']
        address = request.POST['address']
        chairman_name = request.POST['chairman_name']
        contact_person_name = request.POST['contact_person_name']
        contact_person_email = request.POST['contact_person_email']
        contact_person_phone = request.POST['contact_person_phone']
        description = request.POST['description']
        institution_image = request.FILES['institution_logo']
        status = request.POST['status']
        branch = Institution.objects.get(id = ID)
        branch.contactPersonEmail  = contact_person_email
        branch.name = name
        branch.address = address
        branch.chairmanName = chairman_name
        branch.contactPersonName = contact_person_name
        branch.contactPersonPhone = contact_person_phone
        branch.image = institution_image
        branch.Status = status
        branch.description = description
        branch.brochure = brochure
        branch.save()
        return redirect('profile')

    user = Institution.objects.get(id=request.user.id)
    print(user)
    return render(request,'profile.html',{'user':user})


@csrf_exempt
def update_planbanner(request):
    if request.method == "POST":
        ID = request.POST['id']
        ID = request.POST['id']
        Image = request.FILES['intro_banner_image']
        Title = request.POST['title']
        Description = request.POST['description']
        status = request.POST['status']
        branch = planBanner.objects.get(id = ID)
        branch.Image = Image
        branch.Title= Title
        branch.Description = Description
        branch.Status = status
        branch.save()
        return redirect(planbanner)
    return redirect(planbanner)

@csrf_exempt
def update_introbanner(request):
    if request.method == "POST":
        ID = request.POST['id']
        Image = request.FILES['intro_banner_image']
        Title = request.POST['title']
        Description = request.POST['description']
        status = request.POST['status']
        branch = introBanner.objects.get(id = ID)
        branch.Image = Image
        branch.Title= Title
        branch.Description = Description
        branch.Status = status
        branch.save()
        return redirect(introbanner)
    return redirect(introbanner)
    
@csrf_exempt
def update_institutebanner(request):
    if request.method == "POST":
        ID = request.POST['id']
        Image = request.FILES['banner_image']
        Title = request.POST['title']
        status = request.POST['status']
        branch = instituteBanner.objects.get(id = ID)
        branch.Image = Image
        branch.Title= Title
        branch.Status = status
        branch.save()
        return redirect(institutebanner)
    return redirect(institutebanner)

@csrf_exempt
def college(request):
    request.session['title'] = "Colleges"
    if request.user.is_superuser:
        users = Institution.objects.all
        return render(request,"college.html",{'users': users})
    if request.user.is_institute:
        users = Institution.objects.filter(user = request.user.id)
        return render(request,'college.html',{'users':users})
    else:
        return redirect('dashboard')