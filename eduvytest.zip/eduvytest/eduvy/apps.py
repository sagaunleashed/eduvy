from django.apps import AppConfig


class EduvyConfig(AppConfig):
    name = 'eduvy'
